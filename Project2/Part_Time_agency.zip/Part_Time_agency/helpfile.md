Google Fonts:

Lato: https://www.google.com/fonts/specimen/Lato
Roboto: https://www.google.com/fonts/specimen/Roboto

All icons are font awesome!

Use stock photos, like unsplash, for your site!

Colours: 

green: #1cce6c
light grey/beige: #eaeef1
dark grey: #2a2a2a